class displayDatos extends componente
{
  ArrayList<label> labels = new ArrayList<label>();
  grafico graficoDisplay;
  String nombreLabels[] = {"Maximo","Minimo","Promedio"};
  displayDatos(grafico g, pantalla p)
  {
    graficoDisplay = g;
    pPadre = p;
    px = p.posicion.x;
    py = p.posicion.y;
    for(int i = 1; i<=nombreLabels.length; i++)
    {
      py = py+p.alto*0.3;
      labels.add(new label(px + p.ancho*0.1,py,nombreLabels[i-1],graficoDisplay.estadisticas.get(nombreLabels[i-1])));
    }
  }
  void representar()
  {
    for(label lbl : labels)
    {
      lbl.representar();
    }
  }
  void actualizar()
  {
    for(label lbl : labels)
    {
      lbl.dato=graficoDisplay.estadisticas.get(lbl.nombre);
    }
    pPadre.limpiarPantalla();
    representar();
  }
  
  
}
