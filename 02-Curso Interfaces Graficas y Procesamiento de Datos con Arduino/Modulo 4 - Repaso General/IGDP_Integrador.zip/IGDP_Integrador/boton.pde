class boton extends componente{
  boolean estado;
  SoundFile sonido;
  boton(float posicionX, float posicionY, float ancho, float alto, SoundFile sf)
  {
    this.px = posicionX;
    this.py = posicionY;
    this.ancho = ancho;
    this.alto = alto;
    sonido = sf;
    estado = false;
  }
  void representar()
  {
    if(estado)
      fill(0,255,0);
    else
      fill(255,0,0);
    rect(px, py, ancho, alto);
    noFill();
  }
  boolean botonApretado(int x, int y)
  {
    
    if(x>=px && x<=px+ancho && y>=py && y<= py+alto)
    {
      estado = !estado;
      representar();
      sonido.play();
      return true;
    }
    else
      return false;
  }
}
