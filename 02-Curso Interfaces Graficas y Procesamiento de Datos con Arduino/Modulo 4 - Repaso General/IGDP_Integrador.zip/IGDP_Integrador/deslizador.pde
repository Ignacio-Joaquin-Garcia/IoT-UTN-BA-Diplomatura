class deslizador extends componente
{
  float altoPosicion, anchoPosicion, pxPosicion, pyPosicion;
  boolean estado = false;
  int valorAsociado = 0;
  deslizador(pantalla p)
  {
    pPadre = p;
    px = p.posicion.x + p.posicion.x * 0.05;
    py = p.posicion.y + p.posicion.y * 0.3;
    ancho = p.ancho * 0.7;
    altoPosicion = ancho * 0.1;
    anchoPosicion = ancho * 0.02;
    pxPosicion = px;
    pyPosicion = py - altoPosicion*0.5;
    
  }
  void representar()
  {
    line(px, py, px + ancho, py);
    strokeWeight(4);
    line(pxPosicion, pyPosicion, pxPosicion, pyPosicion + altoPosicion);
    strokeWeight(0);
  }
  boolean deslizadorApretado(int x, int y)
  {
    if(x>=pxPosicion && x<=pxPosicion+4 && y>=pyPosicion && y<= pyPosicion+altoPosicion)
    {
      estado = true;
    }
    else
      estado = false;
    return estado;
  }
  
  void deslizar(int x)
  {
    if(x >= px && x <= px + ancho)
    {
      if(x != pxPosicion)
      {
        pxPosicion = x;
        pPadre.limpiarPantalla();
      }
      enviarMensaje("I");
    } 
    representar();
  }
  void enviarMensaje(String m)
  {
    valorAsociado = int(map(pxPosicion, px, px+ancho,0,255));
    println(valorAsociado);
    String mensaje = m;
    mensaje += str(valorAsociado);
    mensaje+="\n";
    miPuerto.write(mensaje); 
  }
}
