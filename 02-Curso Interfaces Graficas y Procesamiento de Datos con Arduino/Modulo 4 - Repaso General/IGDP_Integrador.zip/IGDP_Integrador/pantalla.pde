class pantalla
{
  float ancho;
  float alto;
  PVector posicion;
  color colorFondo;
  ArrayList<componente> componentesPantalla = new ArrayList<componente>();
  pantalla(float ancho, float alto, color colorFondo, PVector posicion)
  {
    this.ancho = ancho;
    this.alto = alto;
    this.colorFondo = colorFondo;
    this.posicion = posicion;   
  }
  void representar()
  {
    fill(colorFondo);
    rect(posicion.x, posicion.y, ancho, alto);
    for(componente c : componentesPantalla)
      c.representar();
    noFill();
  }
  void agregarComponentes(componente c)
  {
    componentesPantalla.add(c);
  }
  void limpiarPantalla()
  {
    rect(posicion.x, posicion.y, ancho, alto);
    representar();
  }
}
