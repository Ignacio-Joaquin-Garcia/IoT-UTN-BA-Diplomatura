class buscadorRostro extends componente
{
  Capture v;
  OpenCV ocv;
  int qFaces = 0;
  buscadorRostro(Capture v, OpenCV ocv, pantalla p)
  {
    this.pPadre = p;
    this.v = v;
    this.ocv = ocv;
    px = p.posicion.x;
    py = p.posicion.y;
  }
  void actualizarV(Capture v)
  {
    this.v = v;
    representar();
  }
  void representar()
  {
    ocv.loadImage(v);
    image(v, px, py);
    noFill();
    stroke(#FF0080);
    Rectangle[] faces = ocv.detect();
    if(faces.length != qFaces)
    {
      qFaces = faces.length;
      if(faces.length > 0)
        enviarMensaje("C");
      else
        enviarMensaje("D");
    }    
    for (int i = 0; i < faces.length; i++) {
      rect(px+faces[i].x, py+faces[i].y, faces[i].width, faces[i].height);
    }
  }
  void enviarMensaje(String m)
  {
    String mensaje = m;
    mensaje += "\n";
    miPuerto.write(mensaje);
  }
}
