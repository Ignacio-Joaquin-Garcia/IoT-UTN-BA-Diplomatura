abstract class componente
{
  float px;
  float py;
  float alto;
  float ancho;
  pantalla pPadre;
  void representar(){};
}
