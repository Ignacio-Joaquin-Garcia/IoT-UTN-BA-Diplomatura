class grafico extends componente
{
  ArrayList<puntoDeGrafico> datos = new ArrayList<puntoDeGrafico>();
  HashMap<String,Float> estadisticas = new HashMap<String,Float>();
  String nombreGrafico;
  color elColor;
  float maximoCociente = 0;
  float maximoY;
  grafico(String nombre,float maximoY, pantalla p)
  {
    this.pPadre = p;
    nombreGrafico = nombre;
    this.maximoY = maximoY;
    estadisticas.put("Maximo", -maximoY);
    estadisticas.put("Minimo", maximoY);
    estadisticas.put("Promedio", 0.0);
    px = p.posicion.x + p.ancho*0.1;
    py = p.posicion.y + p.alto*0.9;
    ancho = p.ancho * 0.8;
    alto = p.alto * 0.8;
    elColor = p.colorFondo;
  }
  void representar()
  {
    fill(0);
    stroke(0);
    strokeWeight(2);
    line(px, py, ancho, py);
    line(px, py, px, py - alto);
    textSize(15);
    text(nombreGrafico, px, py+20);
    text("105s", ancho,py+20);
    for(int i = 0; i<maximoY; i+=10)
    {
      float dato_mapeado_Y = map(i,0,maximoY,py, py - alto);
      text(str(i), px-25,dato_mapeado_Y);
    }
  }

  void agregarDato(float d, long stamp)
  {
    float dato_mapeado_X = map(stamp,0,105,px,px + ancho);
    float dato_mapeado_Y = map(d,0,maximoY,py, py - alto);
    puntoDeGrafico punto = new puntoDeGrafico(d,dato_mapeado_X,dato_mapeado_Y);
    //println(d);
    datos.add(punto);
    float cociente = punto.px/(ancho-px);
    if(punto.px>ancho-px)
      {         
        if(int(cociente) > maximoCociente)
        {
          maximoCociente = int(cociente);
          pPadre.limpiarPantalla();
          representar();
        }
        pushMatrix();
        translate(-ancho*int(cociente) + px*(1+int(cociente)),0);
        punto.representar();
        popMatrix();
      }else
        punto.representar();
    calcularMaximo();
    calcularMinimo();
    calcularPromedio();
  }
  
  void calcularMaximo()
  {
    for(int i = 0; i<datos.size();i++)
    {
      puntoDeGrafico dato = datos.get(i);
      if(dato.dato > estadisticas.get("Maximo"))
        estadisticas.put("Maximo", dato.dato);
    }
  }
  
  void calcularMinimo()
  {
    for(int i = 0; i<datos.size();i++)
    {
      puntoDeGrafico dato = datos.get(i);
      if(dato.dato < estadisticas.get("Minimo"))
        estadisticas.put("Minimo", dato.dato);
    }
  }
  
  void calcularPromedio()
  {
    float t = 0;
    for(int i = 0; i<datos.size();i++)
    {
      puntoDeGrafico dato = datos.get(i);
      t += dato.dato;
    }
    estadisticas.put("Promedio", t/datos.size());
  }
}
