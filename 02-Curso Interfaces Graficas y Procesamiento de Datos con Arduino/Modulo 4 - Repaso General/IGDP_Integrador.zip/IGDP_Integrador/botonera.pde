class botonera extends componente
{
  ArrayList<boton> botones = new ArrayList<boton>();
  int[] estadoBotones;
  float anchoBoton;
  botonera(int c, pantalla p, SoundFile s, float ratio)
  {
    //cantidadBotones = c;
    estadoBotones = new int[c];
    pPadre = p;
    anchoBoton = p.alto*ratio;
    px = p.posicion.x;
    py = p.posicion.y;
    for(int i = 1; i<=c; i++)
    {
      px = px + anchoBoton*2;
      botones.add(new boton(px, py+anchoBoton*0.1, anchoBoton, anchoBoton,s));
    }
  }
  void representar()
  {
    for(boton btn : botones)
    {
      btn.representar();
    }
  }
  
  int botonApretado(int x, int y)
  {
    int r;
    for(boton btn : botones)
    {
      if(btn.botonApretado(x,y))
      {
        if(btn.estado)
          estadoBotones[botones.indexOf(btn)] = 1;
        else
          estadoBotones[botones.indexOf(btn)] = 0;   
        r= botones.indexOf(btn);  
      }
    }    
    r = -1;
    enviarMensaje("E");
    return r;
  }
  void enviarMensaje(String m)
  {
    String mensaje = m;
    for(boton btn : botones)
    {
      mensaje += str(estadoBotones[botones.indexOf(btn)]);
    }
    mensaje+="\n";
    //print(mensaje);
    miPuerto.write(mensaje); 
  }
  
}
