class label extends componente
{
  String nombre;
  float dato;
  String contenido;
  label(float x, float y, String n, float d)
  {
    px = x;
    py = y;
    nombre = n;
    dato = d;
  }
  void representar()
  {
    fill(0);
    textSize(15);
    contenido = nombre + "= " + str(dato);
    text(contenido,px,py);
    strokeWeight(1);
  }
  float getWidht()
  {
    return textWidth(contenido);
  }
}
