class puntoDeGrafico extends componente
{
  float dato;
  puntoDeGrafico(float dato, float x, float y)
  {
    this.dato = dato;
    this.px = x;
    this.py = y;
  }
  void representar()
  {
    fill(0);
    stroke(0);
    ellipse(px,py,5,5);
  }
}
