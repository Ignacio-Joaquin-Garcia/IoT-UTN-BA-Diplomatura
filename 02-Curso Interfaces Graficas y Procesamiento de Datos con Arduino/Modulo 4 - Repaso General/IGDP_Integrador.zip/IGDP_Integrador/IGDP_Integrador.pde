import processing.video.*;
import processing.sound.*;
import processing.serial.*;
import gab.opencv.*;
import java.awt.Rectangle;
import processing.serial.*;
Serial miPuerto;
int lf = 10;
long ultimoTiempo = 0;
int delay = 500;
int i = 0;
String datoLeidoConEvento = "";
float temperatura;
float humedad;

pantalla pantallaBotonera;
pantalla pantallaTemperatura;
pantalla pantallaHumedad;
pantalla pantallaDatosTemperatura;
pantalla pantallaDatosHumedad;
pantalla pantallaCamara;
pantalla pantallaSelector;
pantalla pantallaDeslizador;
grafico graficoTemperatura ;
grafico graficoHumedad;
botonera botoneraSelector;
deslizador miDeslizador;
displayDatos displayDatosTemperatura;
displayDatos displayDatosHumedad;
buscadorRostro buscadorR;
OpenCV opencv;
Capture video;
SoundFile sonido;
void setup()
{
  size(1600,800);
  miPuerto = new Serial(this, Serial.list()[2], 9600);
  miPuerto.bufferUntil(lf);
  
  PVector posicionBotonera = new PVector(0,0);
  PVector posicionPantallaTemperatura = new PVector(0, height*0.2);
  PVector posicionPantallaHumedad = new PVector(0, height*0.6);
  PVector posicionDatosTemperatura = new PVector(width/2,height*0.2);
  PVector posicionDatosHumedad = new PVector(width/2,height*0.6);
  PVector posicionCamara = new PVector(width*3/4, height*0.2);
  PVector posicionDeslizador = new PVector(width*3/4, height*0.6);
  
  String[] cameras = Capture.list();
  println(cameras[0]);
  
  
  
  pantallaBotonera = new pantalla(width, height*0.2, color(100,125,100), posicionBotonera);
  pantallaTemperatura = new pantalla(width/2, height*0.4, color(125,50,100), posicionPantallaTemperatura);
  pantallaHumedad = new pantalla(width/2, height*0.4, color(125,50,100), posicionPantallaHumedad);
  pantallaDatosTemperatura = new pantalla(width/4, height*0.4, color(200,100,150), posicionDatosTemperatura);
  pantallaDatosHumedad = new pantalla(width/4, height*0.4, color(100,255,150), posicionDatosHumedad);
  pantallaCamara = new pantalla(width/4, height*0.8, color(100,100,230), posicionCamara);
  pantallaDeslizador = new pantalla(width/4, height*0.8, color(125,200,230), posicionDeslizador);
  video = new Capture(this,int(pantallaCamara.ancho), int(pantallaCamara.alto)/2, cameras[1]);
  opencv = new OpenCV(this, int(pantallaCamara.ancho), int(pantallaCamara.alto)/2);
  opencv.loadCascade(OpenCV.CASCADE_FRONTALFACE);
  video.start();
  sonido = new SoundFile(this, "switch.mp3");
  botoneraSelector = new botonera(3, pantallaBotonera, sonido,0.8);
  pantallaBotonera.agregarComponentes(botoneraSelector);
  
  graficoTemperatura = new grafico("Temperatura", 125, pantallaTemperatura);
  pantallaTemperatura.agregarComponentes(graficoTemperatura);
  
  graficoHumedad = new grafico("Humedad", 100, pantallaHumedad);
  pantallaHumedad.agregarComponentes(graficoHumedad);
  
  displayDatosTemperatura = new displayDatos(graficoTemperatura,pantallaDatosTemperatura);
  displayDatosHumedad = new displayDatos(graficoHumedad,pantallaDatosHumedad);
  
  buscadorR = new buscadorRostro(video, opencv, pantallaCamara);
  pantallaCamara.agregarComponentes(buscadorR);
  
  miDeslizador = new deslizador(pantallaDeslizador);
  pantallaDeslizador.agregarComponentes(miDeslizador);
  
  pantallaBotonera.representar();
  pantallaTemperatura.representar();
  pantallaHumedad.representar();
  pantallaDatosTemperatura.representar();
  pantallaDatosHumedad.representar();
  pantallaCamara.representar();
  pantallaDeslizador.representar();
  displayDatosTemperatura.representar();
  displayDatosHumedad.representar();
  
}

void draw()
{
  if(datoLeidoConEvento.indexOf("%") > 0)
  {
    temperatura = float(datoLeidoConEvento.substring(0, datoLeidoConEvento.indexOf("%")));
    humedad = float(datoLeidoConEvento.substring(datoLeidoConEvento.indexOf("%")+1));
    long datoTiempo = ultimoTiempo/delay/(1000/delay);
    graficoTemperatura.agregarDato(temperatura, datoTiempo);
    graficoHumedad.agregarDato(humedad, datoTiempo);
    displayDatosTemperatura.actualizar();
    displayDatosHumedad.actualizar();
  }
  buscadorR.representar();
  ultimoTiempo = millis();
}

void serialEvent(Serial p)
{
  datoLeidoConEvento = p.readString();
  //println(datoLeidoConEvento);
}

void mousePressed()
{
  miDeslizador.deslizadorApretado(mouseX, mouseY);
}

void mouseClicked()
{
  botoneraSelector.botonApretado(mouseX,mouseY);
}

void mouseDragged()
{
  if(miDeslizador.estado)
    miDeslizador.deslizar(mouseX);
}
void mouseReleased()
{
  miDeslizador.representar();
}

void captureEvent(Capture c) {
  c.read();
}
