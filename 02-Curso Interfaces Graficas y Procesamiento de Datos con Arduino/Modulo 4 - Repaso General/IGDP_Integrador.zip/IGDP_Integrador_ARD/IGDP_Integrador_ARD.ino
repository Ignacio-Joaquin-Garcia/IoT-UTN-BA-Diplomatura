#include <DHT.h>
#include <DHT_U.h>
#define DHTPIN 2    
#define DHTTYPE DHT22  

DHT dht(DHTPIN, DHTTYPE);
int intensidad = 0;
int estados[]={0,0,0};
void setup() {
  Serial.begin(9600);
  dht.begin();
  pinMode(9, OUTPUT);
  pinMode(10, OUTPUT);
  pinMode(11, OUTPUT);
  pinMode(6, OUTPUT);
  pinMode(5, OUTPUT);
  digitalWrite(11,HIGH);
}

void loop() {
  float temperatura = dht.readTemperature();
  int humedad = dht.readHumidity();
  String mensaje = String(temperatura) + "%" + String(humedad);
  Serial.println(mensaje);
  if(Serial.available()>0)
  {
    String mensajeRecibido = Serial.readStringUntil('\n');
    if(mensajeRecibido.charAt(0)=='E')
    {
      for(int i = 0; i<3;i++)
      {
        estados[i] = mensajeRecibido.charAt(i+1)-48;
      }
      escribirEstados();
      
    }  
    if(mensajeRecibido.charAt(0)=='C')
    {
      digitalWrite(5,LOW);
      digitalWrite(6,HIGH);
    }else
    {
      digitalWrite(5,HIGH);
      digitalWrite(6,LOW);
    }
    if(mensajeRecibido.charAt(0)=='I')
    {
      String intensidadS = mensajeRecibido.substring(1);
      intensidad = intensidadS.toInt();
      //Serial.println(intensidad);
      escribirEstados();
    }
  }
}
void escribirEstados()
{
  for(int i=1; i<4;i++)
  {
    analogWrite(8+i, estados[i-1]*intensidad);
    //digitalWrite(8+i,estados[i-1]);
  }
}


