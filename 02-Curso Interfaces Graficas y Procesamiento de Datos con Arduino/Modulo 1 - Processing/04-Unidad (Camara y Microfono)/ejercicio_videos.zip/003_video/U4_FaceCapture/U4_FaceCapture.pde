import gab.opencv.*;
import processing.video.*;
import java.awt.Rectangle;
import processing.serial.*;

Serial miPuerto;
String datoLeidoConEvento = "";
int lf = 10; 

Capture video;
OpenCV opencv;

void setup() {
  size(640, 480);
  
  // Listar cámaras para depuración
  String[] cameras = Capture.list();
  printArray(cameras);

  if (cameras.length == 0) {
    println("Error: No se detectaron cámaras.");
    exit();
  } else {
    // Inicializamos la captura a la mitad del tamaño de la ventana para ganar velocidad
    video = new Capture(this, 320, 240);
    video.start();
  }

  // Inicializamos OpenCV al mismo tamaño que el video capturado
  opencv = new OpenCV(this, 320, 240);
  opencv.loadCascade(OpenCV.CASCADE_FRONTALFACE);

  // Configuración Serial (Asegúrate de que el índice [0, 1 o 2] sea tu Arduino)
  printArray(Serial.list());
  try {
    miPuerto = new Serial(this, Serial.list()[0], 9600); 
  } catch (Exception e) {
    println("Error: No se pudo abrir el puerto Serial.");
  }
}

void draw() {
  // Solo procesamos si el video tiene frames nuevos
  if (video.width == 0 || video.height == 0) return;

  // Dibujamos el video escalado x2 para llenar la ventana de 640x480
  scale(2);
  opencv.loadImage(video);
  image(video, 0, 0);

  // Estética del recuadro
  noFill();
  stroke(0, 255, 0); // Verde para detección
  strokeWeight(2);

  // Detectar rostros
  Rectangle[] faces = opencv.detect();
  
  // En lugar de un for, usamos un if para ver si hay AL MENOS una cara
    if (faces.length > 0) {
      // Usamos el índice [0] que es la primera cara detectada
      rect(faces[0].x, faces[0].y, faces[0].width, faces[0].height);
  
      // Enviar datos al Arduino
      if (miPuerto != null) {
        String mensaje = faces[0].x + "," + faces[0].y + "\n";
        miPuerto.write(mensaje);
      }
    }

  /*for (int i = 0; i < faces.length; i++) {
    // Dibujar rectángulo sobre la cara
    rect(faces[i].x, faces[i].y, faces[i].width, faces[i].height);

    // Enviar datos al Arduino solo una vez por frame de detección
    // Formato: "X,Y\n"
    if (miPuerto != null) {
      String mensaje = faces[i].x + "," + faces[i].y + "\n";
      miPuerto.write(mensaje);
    }
    
    // Si hay varias caras, solo seguimos la primera (índice 0) para no marear al Arduino
    break; 
  }*/
  
  
}

// Se ejecuta automáticamente cuando la cámara tiene un nuevo frame
void captureEvent(Capture c) {
  c.read();
}

// Escucha lo que el Arduino responde (opcional)
void serialEvent(Serial p) {
  datoLeidoConEvento = p.readStringUntil(lf);
  if (datoLeidoConEvento != null) {
    print("Arduino dice: " + datoLeidoConEvento);
  }
}


/*

Cambios importantes realizados:
Detección de Cámara: Agregué un bloque if para que el programa no "explote" si no encuentra la cámara o si el índice de la lista cambió.

Gestión de null en Serial: Si el Arduino no está conectado, el programa seguirá corriendo (solo te avisará el error en la consola) en lugar de cerrarse.

Filtro de rostros: En el for, agregué un break. Esto es vital: si hay 3 personas en cámara, no quieres enviarle 3 coordenadas distintas al Arduino al mismo tiempo, porque los motores se volverían locos. Con esto, siempre sigue a la "primera" persona detectada.

Velocidad: Mantener el procesamiento en 320x240 y usar scale(2) para mostrarlo es la forma más eficiente de hacer visión artificial en computadoras hogareñas sin que el video se vea lento (lag).
*/
