import processing.video.*;
Movie myMovie;

void setup() {
  size(500, 500);
  myMovie = new Movie(this, "movieEjemplo.mov");
  myMovie.loop();
}

void draw() {
  tint(255, 20);
  image(myMovie, mouseX, mouseY);
}

void movieEvent(Movie m) {
  m.read();
}
