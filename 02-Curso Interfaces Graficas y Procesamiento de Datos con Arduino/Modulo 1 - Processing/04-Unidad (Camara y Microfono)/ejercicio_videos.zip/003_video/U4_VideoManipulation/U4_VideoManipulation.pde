//Modificar cada pixel para que se reproduzca en base a su luminosidad
import processing.video.*;
int escalaDelVideo = 10;
int colum, fil;

Capture video;

void setup() {
  size(640, 480);
  colum = width / escalaDelVideo;
  fil = height / escalaDelVideo;
  video = new Capture(this, colum, fil, Capture.list()[1]);
  video.start();
}

void captureEvent(Capture video) {
  video.read();
}

void draw() {
  background(0);
  video.loadPixels();
  for (int i = 0; i < colum; i++) {
    for (int j = 0; j < fil; j++) {
      int x = i*escalaDelVideo;
      int y = j*escalaDelVideo;

      int loc = (video.width - i - 1) + j * video.width;

      color c = video.pixels[loc];
      float sz = (brightness(c)/255) * escalaDelVideo;

      rectMode(CENTER);
      fill(255);
      noStroke();
      rect(x + escalaDelVideo/2, y + escalaDelVideo/2, sz, sz);
    }
  }
}
