#include <Servo.h>
String orden = "";
Servo miServo;
void setup() {
  Serial.begin(9600);
  miServo.attach(9);
}
void loop() {
  while(Serial.available()>0)
  {
    char c = Serial.read();
    if(c != '\n')
      orden.concat(c);
    else
    {
      if(orden != "")
      {
        orden = orden.substring(0, orden.indexOf(','));
        int valorServo = orden.toInt();
        int pos = map(valorServo, 0, 255, 0, 180);
        Serial.println(pos);
        miServo.write(pos); 
        orden = ""; 
      }
    }
  }  
  delay(1000);
}



