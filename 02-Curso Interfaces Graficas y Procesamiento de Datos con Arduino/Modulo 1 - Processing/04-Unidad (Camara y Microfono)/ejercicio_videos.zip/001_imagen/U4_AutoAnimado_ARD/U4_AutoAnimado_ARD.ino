String info = "";
void setup() {
  Serial.begin(115200);

}

void loop() {
  int btn1 = digitalRead(6);
  int btn2 = digitalRead(7);
  int vAn = analogRead(A0);
  int vMap = map(vAn, 0, 1023, 1, 4);
  info.concat(btn1);
  info.concat('-');
  info.concat(btn2);
  info.concat('-');
  info.concat(vMap);
  info.concat('-');
  Serial.println(info);
  delay(500);
  info = "";
}
