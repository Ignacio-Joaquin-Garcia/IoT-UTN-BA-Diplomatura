PImage miImagen, mascara;

void setup() {
  size(400, 500);
  miImagen = loadImage("fotoEjemplo.jpg");
  mascara = loadImage("mask.jpg");
  mascara.filter(GRAY);
  miImagen.mask(mascara);
  image(miImagen, 0, 100);
}

void draw() {
  
}
