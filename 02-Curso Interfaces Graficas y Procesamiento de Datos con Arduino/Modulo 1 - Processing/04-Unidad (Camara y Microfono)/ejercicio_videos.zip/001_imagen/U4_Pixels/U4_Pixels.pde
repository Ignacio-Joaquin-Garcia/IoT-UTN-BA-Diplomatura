PImage miImagen; 

void setup() {
  size(700, 800);
  miImagen = loadImage("fotoEjemplo.jpg");
  image(miImagen, 0, 0);
  miImagen.loadPixels();
  for(int i = 0; i < (miImagen.width * miImagen.height)/2; i++)
  {
    miImagen.pixels[i + (miImagen.width * miImagen.height)/2] = miImagen.pixels[i];
  }
  miImagen.updatePixels();
  image(miImagen, 0, 400);
}

void draw() {
  
  
}
