PImage miImagen; 
void setup() {
  size(700, 500);
  miImagen = loadImage("UTN_Logo.png"); 
  image(miImagen, 0, 0);
}

void draw() {
  
}
