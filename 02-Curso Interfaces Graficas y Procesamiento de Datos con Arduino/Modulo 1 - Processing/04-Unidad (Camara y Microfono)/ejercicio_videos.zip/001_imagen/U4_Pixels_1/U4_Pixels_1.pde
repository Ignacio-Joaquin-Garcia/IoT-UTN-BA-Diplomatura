void setup()
{
  
  //Modificando pixels
  /*size(500, 200);
  loadPixels();
  for (int i = 0; i < pixels.length; i++) {
  float rand = random(255);
  color c = color(rand);
  pixels[i] = c;
  }
  updatePixels();*/
  
  size(500, 200);
  loadPixels();
  for (int x = 0; x < width; x++) {
    for (int y = 0; y < height; y++) {
      int loc = x + y * width;
      if (x % 2 == 0) {
        pixels[loc] = color(255);
      } else { 
        pixels[loc] = color(0);
      }
    }
  }
  updatePixels();
}
void draw()
{
}
