int filtro;
int filtros[] = {THRESHOLD, GRAY, OPAQUE, INVERT, POSTERIZE, BLUR, ERODE, DILATE};
long ultimoTiempo = 0;
void setup() {
  size(500, 350);  
}


void draw() {
  PImage threshold = loadImage("fotoEjemplo.jpg");
  image(threshold, 0, 0); 
  switch(filtro)
  {
    case 1:
      filter(THRESHOLD);
    break;
    case 2:
      filter(GRAY);
    break;
    case 3:
      filter(OPAQUE);
    break;
    case 4:
      filter(INVERT);
    break;
    case 5:
      filter(POSTERIZE,3);  
    break;
    case 6:
      filter(BLUR);
    break;
    case 7:
        filter(ERODE);
    break;
    case 8:
        filter(DILATE);
    break;
  }
}
void miDelay(int espera)
{
  while(millis() < (ultimoTiempo + espera)){}
    ultimoTiempo = millis();
  return;
}
void keyPressed()
{
  filtro = key - 48;
}
