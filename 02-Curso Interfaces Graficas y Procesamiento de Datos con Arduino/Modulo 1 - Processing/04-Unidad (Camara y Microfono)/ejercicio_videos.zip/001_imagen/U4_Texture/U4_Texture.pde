PImage img;

void setup() {
  size(400, 400, P3D);
  img = loadImage("auto.jpg");
  textureMode(NORMAL);
}

void draw() {
  background(0);
  if (mousePressed) {
    textureWrap(REPEAT); 
  } else {
    textureWrap(CLAMP);
  }
  beginShape();
  texture(img);
  vertex(0, 0, 0, 0);
  vertex(200, 0, 4, 0);
  vertex(250, 400, 4, 4);
  vertex(0, 400, 0, 4);
  endShape();
}
