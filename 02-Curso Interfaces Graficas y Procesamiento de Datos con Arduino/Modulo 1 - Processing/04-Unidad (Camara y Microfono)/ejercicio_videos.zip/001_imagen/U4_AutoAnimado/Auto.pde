// LA CLASE FUERA DE LAS FUNCIONES
class Auto {
  PVector posicion;
  float velocidadX;
  PImage img;
  PShape s;

  Auto(int px, int py, float v, String rutaImg) {
    posicion = new PVector(px, py);
    velocidadX = v;
    img = loadImage(rutaImg); // CARGA UNA SOLA VEZ
    
    // Creamos la forma una sola vez
    s = createShape(RECT, 0, 0, 150, 70); // Tamaño fijo o proporcional
    s.setTexture(img);
    s.setStroke(false);
  }

  void dibujar() {
    shape(s, posicion.x, posicion.y);
  }

  void setVelocidad(int v) {
    this.velocidadX = v;
  }

  void acelerar() {
    // Si quieres que vaya a la izquierda, resta. Si es a la derecha, suma.
    posicion.x -= velocidadX; 
  }

  void reversa() {
    posicion.x += velocidadX;
  }
}
