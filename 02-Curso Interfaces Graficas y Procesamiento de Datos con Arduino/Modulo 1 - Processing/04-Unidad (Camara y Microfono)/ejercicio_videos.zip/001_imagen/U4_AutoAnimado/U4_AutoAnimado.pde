import processing.serial.*;

Serial miPuerto;
String datoLeidoConEvento;
int lf = 10; 
int[] datos = new int[3];
Auto miAuto; // Declaramos el objeto

void setup() {
  size(1500, 400);
  printArray(Serial.list());
  // Asegúrate de que el índice [1] sea el correcto para tu Arduino
  miPuerto = new Serial(this, Serial.list()[1], 115200);
  
  // Inicializamos el auto (le pasamos la ruta de la imagen aquí)
  miAuto = new Auto(700, 250, 2, "auto.png"); 
}

void draw() {
  background(0); // Más eficiente que dibujar un rect negro manual
  println("Boton1: " + datos[0] + " | Boton2: " + datos[1] + " | Velocidad: " + datos[2]);
  if (datos[0] == 1) {
    miAuto.acelerar();
  } else if (datos[1] == 1) {
    miAuto.reversa();
  }
  
  miAuto.setVelocidad(datos[2]);
  miAuto.dibujar();
}

void serialEvent(Serial p) { 
  datoLeidoConEvento = p.readStringUntil(lf); 
  if (datoLeidoConEvento != null) {
    try {
      // Limpiamos espacios y caracteres raros
      datoLeidoConEvento = trim(datoLeidoConEvento);
      String[] lista = split(datoLeidoConEvento, '-');
      
      if (lista.length >= 3) {
        for (int i = 0; i < 3; i++) {
          datos[i] = int(lista[i]);
        }
      }
    } catch (Exception e) {
      println("Error al parsear: " + e.getMessage());
    }
  }
}
